import add_product from "../assets/images/add-product.png"
import analytics_icon from "../assets/images/analytics_icon.png"
import getstart_image from "../assets/images/getstart.png"
import invoice_icon from "../assets/images/invoice_icon.png"
import order_icon from "../assets/images/order_icon.png"
import qr_payment from "../assets/images/payment.png"
import qr_scan from "../assets/images/qr_scan.png"
import send_admin from "../assets/images/send_admin.png"
import welcome_image from "../assets/users/Ecommerce campaign-bro 1.png"
import welcome_bg_image from "../assets/users/Rectangle 34628201.png"


export const images = {
    add_product,
    order_icon,
    invoice_icon,
    analytics_icon,
    welcome_image,
    welcome_bg_image,
    qr_scan ,
    qr_payment,
    getstart_image,
    send_admin
}
